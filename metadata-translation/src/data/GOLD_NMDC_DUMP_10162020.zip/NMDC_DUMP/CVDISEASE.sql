--------------------------------------------------------
--  DDL for Table CVDISEASE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVDISEASE" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
