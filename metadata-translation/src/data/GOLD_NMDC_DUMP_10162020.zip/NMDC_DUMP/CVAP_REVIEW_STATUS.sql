--------------------------------------------------------
--  DDL for Table CVAP_REVIEW_STATUS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVAP_REVIEW_STATUS" ("ID" NUMBER, "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER)
