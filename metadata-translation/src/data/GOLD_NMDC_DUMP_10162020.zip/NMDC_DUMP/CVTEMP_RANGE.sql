--------------------------------------------------------
--  DDL for Table CVTEMP_RANGE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVTEMP_RANGE" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
