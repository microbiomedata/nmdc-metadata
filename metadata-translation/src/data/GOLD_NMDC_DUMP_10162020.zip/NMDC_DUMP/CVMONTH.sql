--------------------------------------------------------
--  DDL for Table CVMONTH
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVMONTH" ("ID" NUMBER, "TERM" VARCHAR2(20 BYTE), "SEQUENCE" NUMBER)
