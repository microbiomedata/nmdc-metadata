--------------------------------------------------------
--  DDL for Table CVSOURCEROCK_KEROGENTYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSOURCEROCK_KEROGENTYPE" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
