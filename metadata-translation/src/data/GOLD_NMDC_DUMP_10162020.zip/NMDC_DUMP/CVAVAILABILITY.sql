--------------------------------------------------------
--  DDL for Table CVAVAILABILITY
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVAVAILABILITY" ("ID" NUMBER, "TERM" VARCHAR2(20 BYTE), "SEQUENCE" NUMBER(*,0))
