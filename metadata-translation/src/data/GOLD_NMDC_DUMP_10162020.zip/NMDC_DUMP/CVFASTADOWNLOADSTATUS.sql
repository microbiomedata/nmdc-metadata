--------------------------------------------------------
--  DDL for Table CVFASTADOWNLOADSTATUS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVFASTADOWNLOADSTATUS" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
