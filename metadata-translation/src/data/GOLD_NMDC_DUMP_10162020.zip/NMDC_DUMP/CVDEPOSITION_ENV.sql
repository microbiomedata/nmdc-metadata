--------------------------------------------------------
--  DDL for Table CVDEPOSITION_ENV
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVDEPOSITION_ENV" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
