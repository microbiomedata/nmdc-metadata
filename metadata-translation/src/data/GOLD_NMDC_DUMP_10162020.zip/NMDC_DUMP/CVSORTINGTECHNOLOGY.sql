--------------------------------------------------------
--  DDL for Table CVSORTINGTECHNOLOGY
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSORTINGTECHNOLOGY" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
