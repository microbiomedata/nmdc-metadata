--------------------------------------------------------
--  DDL for Table CVPLANT_SEX
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVPLANT_SEX" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
