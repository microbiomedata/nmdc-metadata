--------------------------------------------------------
--  DDL for Table CVSAMPLECAPTURE_STATUS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSAMPLECAPTURE_STATUS" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
