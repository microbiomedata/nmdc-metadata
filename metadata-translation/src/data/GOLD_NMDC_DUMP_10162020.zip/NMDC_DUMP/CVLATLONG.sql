--------------------------------------------------------
--  DDL for Table CVLATLONG
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVLATLONG" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
