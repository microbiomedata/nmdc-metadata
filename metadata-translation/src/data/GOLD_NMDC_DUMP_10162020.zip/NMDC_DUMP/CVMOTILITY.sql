--------------------------------------------------------
--  DDL for Table CVMOTILITY
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVMOTILITY" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
