--------------------------------------------------------
--  DDL for Table PROJECT_FUNDING_AGENCY
--------------------------------------------------------

  CREATE TABLE "GOLD"."PROJECT_FUNDING_AGENCY" ("PROJECT_ID" NUMBER(*,0), "INSTITUTION_ID" NUMBER(*,0))
