--------------------------------------------------------
--  DDL for Table CVSEDIMENT_TYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSEDIMENT_TYPE" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
