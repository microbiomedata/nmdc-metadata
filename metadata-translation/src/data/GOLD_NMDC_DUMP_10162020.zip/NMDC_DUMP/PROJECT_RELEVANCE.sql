--------------------------------------------------------
--  DDL for Table PROJECT_RELEVANCE
--------------------------------------------------------

  CREATE TABLE "GOLD"."PROJECT_RELEVANCE" ("PROJECT_ID" NUMBER, "RELEVANCE_ID" NUMBER)
