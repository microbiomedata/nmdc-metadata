--------------------------------------------------------
--  DDL for Table ENVO_TERMS_LABELS
--------------------------------------------------------

  CREATE TABLE "GOLD"."ENVO_TERMS_LABELS" ("ENVO_TERM_ID" VARCHAR2(100 BYTE), "ENVO_TERM_LABEL" VARCHAR2(1000 BYTE))
