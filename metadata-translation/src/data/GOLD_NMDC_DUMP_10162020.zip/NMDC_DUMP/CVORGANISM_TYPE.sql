--------------------------------------------------------
--  DDL for Table CVORGANISM_TYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVORGANISM_TYPE" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
