--------------------------------------------------------
--  DDL for Table CVAP_STATUS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVAP_STATUS" ("ID" NUMBER, "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER)
