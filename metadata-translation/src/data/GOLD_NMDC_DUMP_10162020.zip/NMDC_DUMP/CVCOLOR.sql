--------------------------------------------------------
--  DDL for Table CVCOLOR
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVCOLOR" ("ID" NUMBER(*,0), "TERM" VARCHAR2(20 BYTE), "SEQUENCE" NUMBER(*,0))
