--------------------------------------------------------
--  DDL for Table CVBODY_SUBSITE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVBODY_SUBSITE" ("ID" NUMBER(*,0), "TERM" VARCHAR2(500 BYTE), "SEQUENCE" NUMBER(*,0))
