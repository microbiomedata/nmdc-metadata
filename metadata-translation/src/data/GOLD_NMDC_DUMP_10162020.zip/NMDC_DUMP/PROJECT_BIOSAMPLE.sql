--------------------------------------------------------
--  DDL for Table PROJECT_BIOSAMPLE
--------------------------------------------------------

  CREATE TABLE "GOLD"."PROJECT_BIOSAMPLE" ("PROJECT_ID" NUMBER(*,0), "BIOSAMPLE_ID" NUMBER(*,0))
