--------------------------------------------------------
--  DDL for Table ORGANISM_CELL_ARRANGEMENT
--------------------------------------------------------

  CREATE TABLE "GOLD"."ORGANISM_CELL_ARRANGEMENT" ("ORGANISM_ID" NUMBER(*,0), "CELL_ARRANGEMENT_ID" NUMBER(*,0))
