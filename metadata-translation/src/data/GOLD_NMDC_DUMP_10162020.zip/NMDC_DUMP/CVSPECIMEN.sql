--------------------------------------------------------
--  DDL for Table CVSPECIMEN
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSPECIMEN" ("ID" NUMBER(*,0), "TERM" VARCHAR2(20 BYTE), "SEQUENCE" VARCHAR2(20 BYTE))
