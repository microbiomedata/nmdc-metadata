--------------------------------------------------------
--  DDL for Table CVCULTURE_TYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVCULTURE_TYPE" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
