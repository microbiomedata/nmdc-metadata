--------------------------------------------------------
--  DDL for Table CVOXYGEN_STAT_SAMPLE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVOXYGEN_STAT_SAMPLE" ("ID" NUMBER, "TERM" VARCHAR2(50 BYTE), "SEQUENCE" NUMBER)
