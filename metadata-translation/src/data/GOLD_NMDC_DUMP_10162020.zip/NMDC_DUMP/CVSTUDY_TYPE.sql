--------------------------------------------------------
--  DDL for Table CVSTUDY_TYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSTUDY_TYPE" ("ID" NUMBER(*,0), "TERM" VARCHAR2(30 BYTE), "SEQUENCE" VARCHAR2(20 BYTE))
