--------------------------------------------------------
--  DDL for Table CVGROWTH_HABIT
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVGROWTH_HABIT" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
