--------------------------------------------------------
--  DDL for Table CVSOILFAOCLASS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSOILFAOCLASS" ("ID" NUMBER, "TERM" VARCHAR2(50 BYTE), "SEQUENCE" NUMBER)
