--------------------------------------------------------
--  DDL for Table CVPHENOTYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVPHENOTYPE" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
