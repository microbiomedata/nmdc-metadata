--------------------------------------------------------
--  DDL for Table CVSALINITY
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSALINITY" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
