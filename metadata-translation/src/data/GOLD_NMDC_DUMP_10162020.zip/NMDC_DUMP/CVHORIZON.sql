--------------------------------------------------------
--  DDL for Table CVHORIZON
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVHORIZON" ("ID" NUMBER, "TERM" VARCHAR2(50 BYTE), "SEQUENCE" NUMBER)
