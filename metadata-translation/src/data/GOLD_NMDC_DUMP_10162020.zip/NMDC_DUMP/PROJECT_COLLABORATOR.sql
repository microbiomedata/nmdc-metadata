--------------------------------------------------------
--  DDL for Table PROJECT_COLLABORATOR
--------------------------------------------------------

  CREATE TABLE "GOLD"."PROJECT_COLLABORATOR" ("PROJECT_ID" NUMBER, "INSTITUTION_ID" NUMBER)
