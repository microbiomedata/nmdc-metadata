--------------------------------------------------------
--  DDL for Table CVCELL_ARRANGEMENT
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVCELL_ARRANGEMENT" ("ID" NUMBER(*,0), "TERM" VARCHAR2(20 BYTE), "SEQUENCE" NUMBER(*,0))
