--------------------------------------------------------
--  DDL for Table CVBODY_PRODUCT
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVBODY_PRODUCT" ("ID" NUMBER(*,0), "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER(*,0))
