--------------------------------------------------------
--  DDL for Table CVPROJECT_SUBTYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVPROJECT_SUBTYPE" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
