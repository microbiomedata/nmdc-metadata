--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_SAMPLETYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVHYDROCARBON_SAMPLETYPE" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
