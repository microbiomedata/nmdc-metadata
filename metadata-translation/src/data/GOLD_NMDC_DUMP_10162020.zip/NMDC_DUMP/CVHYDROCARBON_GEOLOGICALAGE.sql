--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_GEOLOGICALAGE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVHYDROCARBON_GEOLOGICALAGE" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
