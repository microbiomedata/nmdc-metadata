--------------------------------------------------------
--  DDL for Table PROJECT_SEQUENCING_CENTER
--------------------------------------------------------

  CREATE TABLE "GOLD"."PROJECT_SEQUENCING_CENTER" ("PROJECT_ID" NUMBER(*,0), "INSTITUTION_ID" NUMBER(*,0))
