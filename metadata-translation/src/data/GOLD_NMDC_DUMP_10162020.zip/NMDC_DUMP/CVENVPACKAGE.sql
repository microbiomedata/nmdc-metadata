--------------------------------------------------------
--  DDL for Table CVENVPACKAGE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVENVPACKAGE" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
