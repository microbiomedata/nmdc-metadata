--------------------------------------------------------
--  DDL for Table CVFINISHING_GOAL
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVFINISHING_GOAL" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
