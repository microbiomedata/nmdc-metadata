--------------------------------------------------------
--  DDL for Table CVUNCULTURED_TYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVUNCULTURED_TYPE" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
