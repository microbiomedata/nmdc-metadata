--------------------------------------------------------
--  DDL for Table ANALYSIS_PROJECT_SRA_RUN_V2
--------------------------------------------------------

  CREATE TABLE "GOLD"."ANALYSIS_PROJECT_SRA_RUN_V2" ("ANALYSIS_PROJECT_ID" NUMBER, "SRA_RUN_ID" VARCHAR2(32 BYTE))
