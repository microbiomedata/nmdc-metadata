--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_SAMPLECOLLPOINT
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVHYDROCARBON_SAMPLECOLLPOINT" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
