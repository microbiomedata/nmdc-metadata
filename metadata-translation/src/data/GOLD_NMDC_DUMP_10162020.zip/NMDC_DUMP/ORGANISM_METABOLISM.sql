--------------------------------------------------------
--  DDL for Table ORGANISM_METABOLISM
--------------------------------------------------------

  CREATE TABLE "GOLD"."ORGANISM_METABOLISM" ("ORGANISM_ID" NUMBER(*,0), "METABOLISM_ID" NUMBER(*,0))
