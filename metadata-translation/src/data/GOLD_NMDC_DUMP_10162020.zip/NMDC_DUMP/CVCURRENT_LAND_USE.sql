--------------------------------------------------------
--  DDL for Table CVCURRENT_LAND_USE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVCURRENT_LAND_USE" ("ID" NUMBER, "TERM" VARCHAR2(50 BYTE), "SEQUENCE" NUMBER)
