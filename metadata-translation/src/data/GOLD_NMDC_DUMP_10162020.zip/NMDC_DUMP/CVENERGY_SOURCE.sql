--------------------------------------------------------
--  DDL for Table CVENERGY_SOURCE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVENERGY_SOURCE" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
