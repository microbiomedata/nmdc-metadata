--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_SAMPLESUBTYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVHYDROCARBON_SAMPLESUBTYPE" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
