--------------------------------------------------------
--  DDL for Table CVBIOLOGICAL_STATUS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVBIOLOGICAL_STATUS" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
