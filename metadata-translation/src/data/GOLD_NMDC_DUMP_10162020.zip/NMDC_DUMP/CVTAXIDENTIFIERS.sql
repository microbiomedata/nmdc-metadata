--------------------------------------------------------
--  DDL for Table CVTAXIDENTIFIERS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVTAXIDENTIFIERS" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
