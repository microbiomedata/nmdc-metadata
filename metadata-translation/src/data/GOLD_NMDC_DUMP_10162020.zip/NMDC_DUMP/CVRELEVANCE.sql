--------------------------------------------------------
--  DDL for Table CVRELEVANCE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVRELEVANCE" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
