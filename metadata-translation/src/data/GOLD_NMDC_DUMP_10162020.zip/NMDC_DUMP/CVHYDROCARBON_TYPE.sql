--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_TYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVHYDROCARBON_TYPE" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
