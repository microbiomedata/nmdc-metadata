--------------------------------------------------------
--  DDL for Table ORGANISM_PHENOTYPE
--------------------------------------------------------

  CREATE TABLE "GOLD"."ORGANISM_PHENOTYPE" ("ORGANISM_ID" NUMBER(*,0), "PHENOTYPE_ID" NUMBER(*,0))
