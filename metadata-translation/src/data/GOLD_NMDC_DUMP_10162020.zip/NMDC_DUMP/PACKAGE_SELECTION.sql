--------------------------------------------------------
--  DDL for Table PACKAGE_SELECTION
--------------------------------------------------------

  CREATE TABLE "GOLD"."PACKAGE_SELECTION" ("PACKAGE_SELECTION_ID" NUMBER, "ORGANISM_ID" NUMBER, "BIOSAMPLE_ID" NUMBER, "PACKAGE_NAME" VARCHAR2(25 BYTE))
