--------------------------------------------------------
--  DDL for Table CVDRAINAGE_CLASS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVDRAINAGE_CLASS" ("ID" NUMBER, "TERM" VARCHAR2(50 BYTE), "SEQUENCE" NUMBER)
