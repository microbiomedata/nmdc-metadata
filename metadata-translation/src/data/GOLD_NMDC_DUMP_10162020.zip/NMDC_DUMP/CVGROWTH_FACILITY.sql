--------------------------------------------------------
--  DDL for Table CVGROWTH_FACILITY
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVGROWTH_FACILITY" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
