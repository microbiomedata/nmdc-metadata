--------------------------------------------------------
--  DDL for Table CVSOURCEROCK_DEPOSITION
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSOURCEROCK_DEPOSITION" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
