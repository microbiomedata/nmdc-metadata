--------------------------------------------------------
--  DDL for Table CVOXYGEN_PRESENCE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVOXYGEN_PRESENCE" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
