--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_LITHOLOGY
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVHYDROCARBON_LITHOLOGY" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
