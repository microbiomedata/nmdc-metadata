--------------------------------------------------------
--  DDL for Table CVSOURCEROCK_LITHOLOGY
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSOURCEROCK_LITHOLOGY" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
