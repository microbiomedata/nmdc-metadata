--------------------------------------------------------
--  DDL for Table CVGEBA_REVIEW_STATUS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVGEBA_REVIEW_STATUS" ("ID" NUMBER, "TERM" VARCHAR2(50 BYTE), "SEQUENCE" NUMBER)
