--------------------------------------------------------
--  DDL for Table CVPROFILE_POSITION
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVPROFILE_POSITION" ("ID" NUMBER, "TERM" VARCHAR2(50 BYTE), "SEQUENCE" NUMBER)
