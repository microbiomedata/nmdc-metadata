--------------------------------------------------------
--  DDL for Table CVHOST_GENDER
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVHOST_GENDER" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
