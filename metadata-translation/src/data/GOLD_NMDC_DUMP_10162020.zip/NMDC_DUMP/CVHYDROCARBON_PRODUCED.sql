--------------------------------------------------------
--  DDL for Table CVHYDROCARBON_PRODUCED
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVHYDROCARBON_PRODUCED" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
