--------------------------------------------------------
--  DDL for Table CVVIRUSENRICHMENTAPPROACH
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVVIRUSENRICHMENTAPPROACH" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
