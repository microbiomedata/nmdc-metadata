--------------------------------------------------------
--  DDL for Table CVPROJECT_STATUS
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVPROJECT_STATUS" ("ID" NUMBER(*,0), "TERM" VARCHAR2(100 BYTE), "SEQUENCE" NUMBER(*,0))
