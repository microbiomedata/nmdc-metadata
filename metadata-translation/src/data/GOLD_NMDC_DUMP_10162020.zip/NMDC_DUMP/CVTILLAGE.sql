--------------------------------------------------------
--  DDL for Table CVTILLAGE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVTILLAGE" ("ID" NUMBER, "TERM" VARCHAR2(50 BYTE), "SEQUENCE" NUMBER)
