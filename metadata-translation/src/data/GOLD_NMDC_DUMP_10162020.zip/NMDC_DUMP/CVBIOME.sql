--------------------------------------------------------
--  DDL for Table CVBIOME
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVBIOME" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
