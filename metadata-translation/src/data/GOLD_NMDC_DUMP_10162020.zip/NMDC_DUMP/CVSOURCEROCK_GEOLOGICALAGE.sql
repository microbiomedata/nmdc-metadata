--------------------------------------------------------
--  DDL for Table CVSOURCEROCK_GEOLOGICALAGE
--------------------------------------------------------

  CREATE TABLE "GOLD"."CVSOURCEROCK_GEOLOGICALAGE" ("ID" NUMBER, "TERM" VARCHAR2(200 BYTE), "SEQUENCE" NUMBER)
