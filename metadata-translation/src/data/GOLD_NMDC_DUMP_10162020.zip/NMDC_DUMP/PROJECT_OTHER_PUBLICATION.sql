--------------------------------------------------------
--  DDL for Table PROJECT_OTHER_PUBLICATION
--------------------------------------------------------

  CREATE TABLE "GOLD"."PROJECT_OTHER_PUBLICATION" ("PROJECT_ID" NUMBER(*,0), "PUBLICATION_ID" NUMBER(*,0))
